<?php

namespace App\Models;

use CodeIgniter\Model;

class onlinestoremodal extends Model
{
    protected $table = 'carousels';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'description', 'link', 'image', 'image_mobile', 'visibility', 'created_at', 'updated_at'];
    protected $useTimestamps = true;

    public function getabout()
    {
        return $this->db->table('aboutpage')->where('id', 1)->get()->getRowArray();
    }

    public function getcontact()
    {
        return $this->db->table('contactpage')->where('id', 1)->get()->getRowArray();
    }


    public function GetallCarouselData()
    {
        return $this->db->table('carousels')->get()->getResultArray();
    }

    public function GetallBlogsData()
    {
        return $this->db->table('blogs')->where('blog_visibility', 'active')->get()->getResultArray();
    }

    public function getAllMembers()
    {
        return $this->db->table('team_members')->orderBy('order', 'ASC')->get()->getResultArray();
    }

    public function updateAbout($data)
    {
        return $this->db->table('aboutpage')->update(1, $data);
    }

    public function getTags()
    {
        return $this->db->table('tags')->get()->getResultArray();
    }

    public function getproduct()
    {
        return $this->db->table('products')->select('product_id, product_title')->get()->getResultArray();
    }

    public function getallblogs()
    {
        return $this->db->table('blog_settings')->where('id', 1)->get()->getRowArray();
    }

    public function getsingleblogs()
    {
        return $this->db->table('singleblog_data')->where('id', 3)->get()->getRowArray();
    }

    public function getoscollection()
    {
        return $this->db->table('os_collections')->where('id', 1)->get()->getRowArray();
    }

    public function getoslogo()
    {
        return $this->db->table('home_logo')->get()->getResultArray();
    }

    public function getAllAvailableCollections()
    {
        return $this->db->table('collection')->get()->getResultArray();
    }


    public function gethomecollection()
    {
        return $this->db->table('home_collection')->where('id', 1)->get()->getRowArray();
    }

    public function getAllAvailableProducts()
    {
        return $this->db->table('products') // Replace 'products' with your actual table name
            ->select('product_id, product_title') // Fetch only necessary field
            ->get()
            ->getResultArray(); // Return the result as an array
    }

    public function getHomeProductIds()
    {
        $result = $this->db->table('home_product')
            ->select('product_id')
            ->where('id', 1) // Assuming you always fetch the record with ID 1
            ->get()
            ->getRowArray();

        return $result['product_id'] ?? ''; // Return the product IDs as a comma-separated string
    }


    public function getHomeBlogIds()
    {
        $row = $this->db->table('home_blog')->where('id', 1)->get()->getRowArray();
        return $row ? explode(',', $row['blog_id']) : []; // Return an array of saved blog IDs
    }

    public function getAllCarousel2()
    {
        return $this->db->table('home_carousel2')->get()->getResultArray();
    }

    public function getImagedata()
    {
        return $this->db->table('home_image')->get()->getResultArray();
    }

    public function getpages()
    {
        return $this->db->table('header_pages')->get()->getResultArray();
    }


    public function GetAllCollections()
    {
        return $this->db->table('collection')->where('collection_visibility', 'visibile')->get()->getResultArray();
    }

    public function InsertHeaderFirstData($data)
    {
        return $this->db->table('header_first')->insert($data);
    }




}
