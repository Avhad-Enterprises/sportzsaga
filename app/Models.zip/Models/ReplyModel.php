<?php
namespace App\Models;

use CodeIgniter\Model;

class ReplyModel extends Model
{
    protected $table = 'cs_mails';
    protected $primaryKey = 'id';
    protected $allowedFields = ['msg_no', 'subject', 'from_email', 'to_email', 'user_id', 'full_message', 'attachments', 'email_date', 'tags', 'assigned_agent', 'status', 'message_type', 'replied_to_msgno', 'cc_email', 'bcc_email'];

    public function checkExistingEmail($msgNo)
    {
        return $this->where('msg_no', $msgNo)->first();
    }

    public function getUserIdByEmail($email)
    {
        $db = \Config\Database::connect();
        $query = $db->query("SELECT user_id FROM users WHERE email = ?", [$email]);
        $result = $query->getRow();
        return $result ? $result->id : null;
    }

    public function getTagsForMessage($message)
    {
        $db = \Config\Database::connect();
        $tags = $db->table('cs_tags')->orderBy('priority', 'DESC')->get()->getResult();
        
        $matchedTags = [];
        foreach ($tags as $tag) {
            $keywords = explode(',', $tag->tag_keywords);
            $keywordCount = 0;
            
            foreach ($keywords as $keyword) {
                if (stripos($message, trim($keyword)) !== false) {
                    $keywordCount++;
                }
            }
            
            if ($keywordCount > 0) {
                $matchedTags[] = [
                    'tag_name' => $tag->tag_name,
                    'matches' => $keywordCount
                ];
            }
        }

        // Sort by number of matches
        usort($matchedTags, function($a, $b) {
            return $b['matches'] - $a['matches'];
        });

        return array_column($matchedTags, 'tag_name');
    }

    public function getAgentForTags($tags)
    {
        if (empty($tags)) return null;
        
        $primaryTag = $tags[0];
        $db = \Config\Database::connect();
        
        $query = $db->query("
            SELECT agent_name 
            FROM cs_agents 
            WHERE status = 'active' 
            AND FIND_IN_SET(?, cs_tags) > 0 
            ORDER BY RAND() 
            LIMIT 1
        ", [$primaryTag]);
        
        $result = $query->getRow();
        return $result ? $result->agent_name : null;
    }

    public function getAllAgents()
    {
        $db = \Config\Database::connect();
        return $db->table('cs_agents')
                ->where('status', 'active')
                ->get()
                ->getResult();
    }

    public function getAgent($msgNo)
    {
        $db = \Config\Database::connect();
        return $db->table('cs_mails')
                ->where('msg_no', $msgNo)
                ->get()
                ->getResult();
    }

    public function updateAgent($msgNo, $agentId, $userId)
    {
        $db = \Config\Database::connect();
        return $db->table('cs_mails')
                ->where('msg_no', $msgNo)
                ->update([
                    'assigned_agent' => $agentId,
                    'updated_by' => $userId,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
    }

    public function getMacrosByTags($tags)
    {
        $db = \Config\Database::connect();
        $tagArray = explode(',', $tags);
    
        $query = $db->table('cs_macros')
                    ->groupStart()
                    ->orWhereIn('cs_tags', $tagArray)
                    ->groupEnd()
                    ->get();
    
        return $query->getResult();
    }
    
    public function getAllMacros()
    {
        $db = \Config\Database::connect();
        $query = $db->table('cs_macros')->get();
        return $query->getResult();
    }

    /*public function getMacroContent($macroId)
    {
        $db = \Config\Database::connect();
        return $db->table('cs_macros')
                ->where('id', $macroId)
                ->get()
                ->getRow();
    }*/

    public function getUserData($userId)
    {
        $db = \Config\Database::connect();
        return $db->table('users')
                ->where('user_id', $userId)
                ->get()
                ->getRow();
    }

    public function getEmailThread($msgNo) {
        $thread = [];
        $currentMsg = $msgNo;
        
        // First get all replies to this message
        $replies = $this->where('replied_to_msgno', $msgNo)
                       ->orderBy('email_date', 'ASC')
                       ->findAll();
        
        // Get the current message
        $currentEmail = $this->where('msg_no', $msgNo)->first();
        if ($currentEmail) {
            $thread[] = $currentEmail;
            
            // If this is a reply, get the original message and any other replies
            if ($currentEmail['replied_to_msgno']) {
                $originalAndOtherReplies = $this->getEmailThread($currentEmail['replied_to_msgno']);
                $thread = array_merge($thread, $originalAndOtherReplies);
            }
        }
        
        // Add all replies
        $thread = array_merge($thread, $replies);
        
        // Remove duplicates based on msg_no
        $uniqueThread = array_unique(array_column($thread, 'msg_no'));
        $thread = array_intersect_key($thread, $uniqueThread);
        
        // Sort by date
        usort($thread, function($a, $b) {
            return strtotime($a['email_date']) - strtotime($b['email_date']);
        });
        
        return $thread;
    }
    
    public function findRelatedEmail($subject, $fromEmail) {
        // Remove common reply prefixes
        $cleanSubject = preg_replace('/^(RE:|Re:|FWD:|Fwd:)\s*/i', '', $subject);
        $cleanSubject = trim($cleanSubject);
        
        // Look for an existing email with matching subject (ignoring Re:/Fwd:)
        return $this->where('from_email', $fromEmail)
                    ->like('subject', $cleanSubject)
                    ->orderBy('email_date', 'DESC')
                    ->first();
    }

    public function getEmailThreads() {
        log_message('info', 'Fetching email threads');
        
        // First get all root emails (those without replied_to_msgno)
        $rootEmails = $this->where('replied_to_msgno IS NULL', null, false)
                          ->orderBy('email_date', 'DESC')
                          ->findAll();
                          
        log_message('info', 'Found ' . count($rootEmails) . ' root emails');
    
        // For each root email, get its replies
        $threads = [];
        foreach ($rootEmails as $rootEmail) {
            $thread = [
                'root' => $rootEmail,
                'replies' => $this->where('replied_to_msgno', $rootEmail['msg_no'])
                                 ->orderBy('email_date', 'DESC')
                                 ->findAll(),
                'latest_date' => $rootEmail['email_date']
            ];
            
            // Update latest date if there are replies
            if (!empty($thread['replies'])) {
                $latestReply = max(array_column($thread['replies'], 'email_date'));
                $thread['latest_date'] = $latestReply;
            }
            
            $threads[] = $thread;
        }
        
        // Sort threads by latest message date
        usort($threads, function($a, $b) {
            return strtotime($b['latest_date']) - strtotime($a['latest_date']);
        });
        
        log_message('info', 'Processed ' . count($threads) . ' email threads');
        return $threads;
    }

    public function getCompleteThread($msgno) {
        log_message('info', 'Fetching complete thread for message: ' . $msgno);
        
        // First get the original message
        $originalMessage = $this->where('msg_no', $msgno)->first();
        if (!$originalMessage) {
            throw new \Exception('Original message not found');
        }

        // Get all related messages using recursive CTE
        $sql = "WITH RECURSIVE conversation_thread AS (
            -- Base case: start with the original message
            SELECT *, 0 as depth
            FROM cs_mails
            WHERE msg_no = ?
            
            UNION ALL
            
            -- Recursive case: get replies and related messages
            SELECT m.*, ct.depth + 1
            FROM cs_mails m
            INNER JOIN conversation_thread ct
            ON m.replied_to_msgno = ct.msg_no
            OR ct.msg_no = m.replied_to_msgno
            WHERE m.msg_no != ?
        )
        SELECT DISTINCT *
        FROM conversation_thread
        ORDER BY email_date ASC";

        $result = $this->db->query($sql, [$msgno, $msgno])->getResultArray();
        log_message('info', 'Found ' . count($result) . ' messages in thread');
        
        return $result;
    }

    public function getCSTagsList()
    {
        return $this->db->table('cs_tags')
                        ->select('id, tag_name')
                        ->get()
                        ->getResultArray();
    }
    
    public function saveMacro($data)
    {
        return $this->db->table('cs_macros')->insert($data);
    }
    
    // Modify your existing getMacroContent method to handle variables
    public function getMacroContent($macroId)
    {
        try {
            $builder = $this->db->table('cs_macros');
            $macro = $builder->select('cs_tags, reply_type, to_email, cc_email, bcc_email, reply_msg, macro_attachments')
                           ->where('id', $macroId)
                           ->get()
                           ->getRowArray();
                           
            if (!$macro) {
                log_message('error', 'Macro not found with ID: ' . $macroId);
                return null;
            }
            
            return $macro;
        } catch (\Exception $e) {
            log_message('error', 'Database error while fetching macro: ' . $e->getMessage());
            return null;
        }
    }
    
    private function replaceVariables($content)
    {
        preg_match_all('/`(.*?)`/', $content, $matches);
        
        foreach ($matches[1] as $variable) {
            $value = $this->getVariableValue($variable);
            $content = str_replace("`$variable`", $value, $content);
        }
        
        return $content;
    }
    
    private function getVariableValue($variable)
    {
        // Add logic to fetch appropriate data based on variable
        $userId = session()->get('current_user_id');
        
        switch ($variable) {
            case 'customer_name':
            case 'customer_email':
            case 'customer_mobile':
            case 'customer_address':
                $userData = $this->db->table('users')
                                    ->where('id', $userId)
                                    ->get()
                                    ->getRow();
                return $userData->{$variable} ?? '';
                
            case 'recent_order_number':
            case 'recent_order_status':
            // Add cases for all order-related variables
                $orderData = $this->db->table('order_management')
                                     ->where('user_id', $userId)
                                     ->orderBy('order_date', 'DESC')
                                     ->get()
                                     ->getRow();
                return $orderData->{$variable} ?? '';
                
            case 'current_agent_name':
                return session()->get('admin_name');

            case 'current_admin_email':
                return session()->get('admin_email');
            
        }
    }






    
    
}
