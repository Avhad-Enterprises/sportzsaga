<?php

namespace App\Models;

use CodeIgniter\Model;

class Footer_model extends Model
{
    protected $table = 'footer';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'description', 'image'];

    public function getfooterdata()
    {
        return $this->findAll();
    }

    public function geteditfooterdata($id)
    {
        return $this->where('id', $id)->findAll();
    }

    public function updatefooterdata($id, $data)
    {
        return $this->update($id, $data);
    }
}
